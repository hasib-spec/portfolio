import { useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';
import AsciiCanvas from '../components/AsciiCanvas';

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const canvasWrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const content = contentRef.current;
    const canvasWrap = canvasWrapRef.current;
    if (!content || !canvasWrap) return;

    const children = content.querySelectorAll('.hero-animate');
    children.forEach((el, i) => {
      const htmlEl = el as HTMLElement;
      htmlEl.style.opacity = '0';
      htmlEl.style.transform = 'translateY(30px)';
      setTimeout(() => {
        htmlEl.style.transition = `opacity 0.8s cubic-bezier(0.33, 1, 0.68, 1) ${i * 0.15}s, transform 0.8s cubic-bezier(0.33, 1, 0.68, 1) ${i * 0.15}s`;
        htmlEl.style.opacity = '1';
        htmlEl.style.transform = 'translateY(0)';
      }, 300);
    });

    canvasWrap.style.opacity = '0';
    canvasWrap.style.transform = 'translateX(40px)';
    setTimeout(() => {
      canvasWrap.style.transition = 'opacity 1s cubic-bezier(0.33, 1, 0.68, 1) 0.5s, transform 1s cubic-bezier(0.33, 1, 0.68, 1) 0.5s';
      canvasWrap.style.opacity = '1';
      canvasWrap.style.transform = 'translateX(0)';
    }, 400);
  }, []);

  const handleExploreClick = (e: React.MouseEvent) => {
    e.preventDefault();
    document.querySelector('#research')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative min-h-[100dvh] flex items-center overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #0A192F 0%, #112240 50%, #0A192F 100%)',
      }}
    >
      <div className="max-w-[1200px] mx-auto w-full px-6 pt-20">
        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-8 lg:gap-12 items-center min-h-[calc(100dvh-80px)]">
          {/* Left Column - Text */}
          <div ref={contentRef} className="flex flex-col justify-center py-12 lg:py-0">
            <span
              className="hero-animate font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-4"
              style={{ color: '#64FFDA' }}
            >
              Computational Toxicology · PBTK/PBPK Modelling · Scientific Computing
            </span>

            <h1
              className="hero-animate font-display font-bold leading-[1.1] mb-4"
              style={{
                color: '#E6F1FF',
                fontSize: 'clamp(48px, 6vw, 72px)',
              }}
            >
              Haseeb Ahmad
            </h1>

            <h2
              className="hero-animate font-body text-xl lg:text-2xl font-semibold mb-6"
              style={{
                color: '#8892B0',
                maxWidth: 520,
                lineHeight: 1.4,
              }}
            >
              Zoology undergraduate developing computational approaches for mechanistic toxicity prediction.
            </h2>

            <p
              className="hero-animate font-body text-base lg:text-lg mb-8"
              style={{
                color: '#8892B0',
                maxWidth: 520,
                lineHeight: 1.6,
              }}
            >
              Independent research spanning PBTK modelling, quantitative Adverse Outcome Pathway (qAOP) frameworks, Monte Carlo methods, and scientific software development. Seeking doctoral research opportunities to develop rigorous, reproducible approaches to computational toxicology.
            </p>

            <div className="hero-animate flex flex-wrap items-center gap-4">
              <a
                href="#research"
                onClick={handleExploreClick}
                className="font-body text-base font-medium px-8 py-3.5 rounded-lg transition-all duration-200 hover:scale-105"
                style={{
                  backgroundColor: '#F6A623',
                  color: '#0A192F',
                }}
              >
                View Research Portfolio
              </a>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="font-body text-base font-medium transition-colors duration-200 hover:underline"
                style={{ color: '#64FFDA' }}
              >
                GitHub · CV · Contact →
              </a>
            </div>
          </div>

          {/* Right Column - ASCII Canvas (desktop) / Portrait (mobile) */}
          <div
            ref={canvasWrapRef}
            className="hidden lg:block relative"
            style={{ height: 'clamp(400px, 50vh, 600px)' }}
          >
            <AsciiCanvas />
          </div>

          {/* Mobile Portrait */}
          <div className="lg:hidden flex justify-center">
            <img
              src="/portrait.jpg"
              alt="Haseeb Ahmad"
              className="w-48 h-64 object-cover rounded-xl"
              style={{
                border: '2px solid #233554',
                boxShadow: '0 20px 40px rgba(2, 12, 27, 0.5)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        style={{ animation: 'bounce 2s infinite', opacity: 0.6 }}
      >
        <span className="font-body text-xs uppercase tracking-wider" style={{ color: '#8892B0' }}>
          Scroll
        </span>
        <ChevronDown size={20} style={{ color: '#8892B0' }} />
      </div>

      <style>{`
        @keyframes bounce {
          0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
          40% { transform: translateX(-50%) translateY(-10px); }
          60% { transform: translateX(-50%) translateY(-5px); }
        }
      `}</style>
    </section>
  );
}
