import { Linkedin, Github, Mail } from 'lucide-react';

const NAV_LINKS = [
  { label: 'About', href: '#hero' },
  { label: 'Recognition', href: '#achievements' },
  { label: 'Research', href: '#research' },
  { label: 'Skills', href: '#skills' },
  { label: 'Philosophy', href: '#philosophy' },
  { label: 'Contact', href: '#contact' },
];

const SOCIAL_LINKS = [
  { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
  { icon: Github, href: 'https://github.com/hasib-spec/', label: 'GitHub' },
  { icon: Mail, href: 'mailto:haedu59@gmail.com', label: 'Email' },
];

export default function Footer() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer
      style={{
        backgroundColor: '#0A192F',
        borderTop: '1px solid #233554',
        padding: '40px 0',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Left */}
          <span
            className="font-body text-[13px]"
            style={{ color: '#8892B0' }}
          >
            &copy; 2025 Haseeb Ahmad · Computational Toxicology Research Portfolio
          </span>

          {/* Center — Nav */}
          <div className="hidden md:flex flex-wrap items-center justify-center gap-6">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-body text-[13px] font-medium transition-colors duration-200"
                style={{ color: '#A8B2D1' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = '#64FFDA';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#A8B2D1';
                }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Right — Social */}
          <div className="flex items-center gap-4">
            {SOCIAL_LINKS.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={social.label}
                className="transition-colors duration-200"
                style={{ color: '#A8B2D1' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = '#64FFDA';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#A8B2D1';
                }}
              >
                <social.icon size={20} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
