import { useEffect, useRef } from 'react';

const SKILL_GROUPS = [
  {
    type: 'COMPUTATIONAL MODELLING',
    title: 'Mechanistic & Statistical Modelling',
    desc: 'Independent study and implementation of physiologically-based and probabilistic modelling frameworks used in modern computational toxicology.',
    evidence: [
      'PBTK / PBPK multi-compartment modelling',
      'Quantitative Adverse Outcome Pathway (qAOP) frameworks',
      'Monte Carlo simulation and uncertainty propagation',
      'GUTS-SD (General Unified Threshold of Survival)',
      'Biotic Ligand Models (BLM) for metal bioavailability',
      'Dose–response modelling and hazard characterisation',
    ],
  },
  {
    type: 'SCIENTIFIC PROGRAMMING',
    title: 'Reproducible Computational Workflows',
    desc: 'Building documented, tested, and version-controlled scientific software — not prototypes, but tools intended to be re-run and inspected by others.',
    evidence: [
      'Python scientific stack (NumPy, SciPy, pandas, matplotlib)',
      'FastAPI for reproducible model execution APIs',
      'React / TypeScript frontends for parameter exploration',
      'Numerical ODE solving and parameter optimisation',
      'Git-based version control and code documentation',
      'Unit testing for numerical and statistical components',
    ],
  },
  {
    type: 'RESEARCH METHODS',
    title: 'Literature, Validation & Communication',
    desc: 'The non-coding parts of computational research: reading the literature critically, designing validation against gold-standard data, and writing up results honestly.',
    evidence: [
      'Literature synthesis across toxicology, modelling, and regulatory science',
      'Model validation against gold-standard reference datasets',
      'Quantitative uncertainty and sensitivity analysis',
      'Explicit limitations and boundary-condition reporting',
      'Scientific writing and manuscript preparation',
      'Interdisciplinary communication across biology and computing',
    ],
  },
];

export default function Edge() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current;
    if (!section || !cards) return;

    const cardEls = cards.querySelectorAll('.edge-card');
    cardEls.forEach((card) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(50px)';
    });

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          cardEls.forEach((card, i) => {
            const el = card as HTMLElement;
            setTimeout(() => {
              el.style.transition = 'opacity 0.8s cubic-bezier(0.33, 1, 0.68, 1), transform 0.8s cubic-bezier(0.33, 1, 0.68, 1)';
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
            }, i * 120);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="skills"
      ref={sectionRef}
      style={{ backgroundColor: '#0A192F', padding: '100px 0' }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-4 block"
            style={{ color: '#64FFDA' }}
          >
            Research &amp; Technical Skills
          </span>
          <h2
            className="font-display text-4xl lg:text-[40px] font-bold mb-4"
            style={{ color: '#E6F1FF' }}
          >
            Methods &amp; Tools
          </h2>
          <p
            className="font-body text-lg"
            style={{ color: '#8892B0', maxWidth: 640 }}
          >
            The intersection of biology, mathematical modelling, and programming where I have built working proficiency through independent study and project work.
          </p>
        </div>

        {/* Skill Cards */}
        <div ref={cardsRef} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {SKILL_GROUPS.map((group) => (
            <div
              key={group.type}
              className="edge-card rounded-xl p-10 transition-all duration-300"
              style={{
                backgroundColor: '#112240',
                border: '1px solid transparent',
                willChange: 'transform',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget;
                el.style.borderColor = 'rgba(100, 255, 218, 0.4)';
                el.style.boxShadow = '0 0 30px rgba(100, 255, 218, 0.08)';
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget;
                el.style.borderColor = 'transparent';
                el.style.boxShadow = 'none';
              }}
            >
              <span
                className="font-body text-[13px] font-medium uppercase tracking-wider mb-4 block"
                style={{ color: '#F6A623' }}
              >
                {group.type}
              </span>
              <h3
                className="font-body text-2xl font-semibold mb-4"
                style={{ color: '#E6F1FF' }}
              >
                {group.title}
              </h3>
              <p
                className="font-body text-base mb-6"
                style={{ color: '#8892B0', lineHeight: 1.7 }}
              >
                {group.desc}
              </p>

              <div>
                <span
                  className="font-body text-[13px] font-medium uppercase tracking-wider mb-3 block"
                  style={{ color: '#A8B2D1' }}
                >
                  Specific Competencies
                </span>
                <ul className="space-y-2">
                  {group.evidence.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span
                        className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                        style={{ backgroundColor: '#64FFDA' }}
                      />
                      <span className="font-body text-sm" style={{ color: '#A8B2D1' }}>
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
