import { useEffect, useRef, useState } from 'react';

const ACHIEVEMENTS = [
  {
    number: '01',
    title: 'Magna Charta Observatory 2025',
    org: 'International Essay Competition',
    desc: 'Highly Commended Essayist — selected from 37+ countries for a contribution on higher education discourse.',
  },
  {
    number: '02',
    title: 'Open Doors International Olympiad 2025',
    org: 'Biotechnology Track',
    desc: 'High Achiever — competitive assessment across biotechnology and molecular biosciences.',
  },
  {
    number: '03',
    title: 'ISCOMS 2026',
    org: 'Groningen, Netherlands',
    desc: 'Accepted Presenter — International Student Congress of (Bio)Medical Sciences. Selected to present computational toxicology research; the only accepted contribution from Pakistan this year.',
  },
  {
    number: '04',
    title: 'Harvard Aspire Leaders Program 2025',
    org: 'Harvard University',
    desc: 'Alumni — leadership development program for early-career researchers and practitioners across disciplines.',
  },
];

const STATS = [
  { value: 82.1, suffix: '%', label: 'Validation Pass Rate (±2× LC50)' },
  { value: 9830, suffix: '', label: 'Lines of Python (Ichthyon)' },
  { value: 12, suffix: '', label: 'PBTK Compartments Modelled' },
  { value: 28, suffix: '', label: 'Compounds Validated' },
];

function AnimatedCounter({ target, suffix, prefix }: { target: number; suffix: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 1500;
          const start = performance.now();

          const animate = (now: number) => {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [target]);

  return (
    <span ref={ref}>
      {prefix}
      {count.toLocaleString()}
      {suffix}
    </span>
  );
}

export default function Achievements() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current;
    if (!section || !cards) return;

    const cardEls = cards.querySelectorAll('.achievement-card');

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          cardEls.forEach((card, i) => {
            const el = card as HTMLElement;
            setTimeout(() => {
              el.style.transition = 'opacity 0.7s cubic-bezier(0.33, 1, 0.68, 1), transform 0.7s cubic-bezier(0.33, 1, 0.68, 1)';
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
            }, i * 150);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(section);

    // Set initial state
    cardEls.forEach((card) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="achievements"
      ref={sectionRef}
      style={{ backgroundColor: '#0A192F', padding: '100px 0' }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-4 block"
            style={{ color: '#64FFDA' }}
          >
            Selected Recognition
          </span>
          <h2
            className="font-display text-4xl lg:text-[40px] font-bold mb-4"
            style={{ color: '#E6F1FF' }}
          >
            Honours &amp; Presentations
          </h2>
          <p
            className="font-body text-lg"
            style={{ color: '#8892B0', maxWidth: 520 }}
          >
            External recognition and scientific presentations beyond my undergraduate programme.
          </p>
        </div>

        {/* Achievement Cards */}
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {ACHIEVEMENTS.map((a) => (
            <div
              key={a.number}
              className="achievement-card group rounded-xl p-8 transition-all duration-300"
              style={{
                backgroundColor: '#112240',
                border: '1px solid transparent',
                willChange: 'transform',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget;
                el.style.transform = 'translateY(-8px)';
                el.style.borderColor = 'rgba(100, 255, 218, 0.5)';
                el.style.boxShadow = '0 20px 40px rgba(2, 12, 27, 0.5)';
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget;
                el.style.transform = 'translateY(0)';
                el.style.borderColor = 'transparent';
                el.style.boxShadow = 'none';
              }}
            >
              <span
                className="font-mono text-2xl font-bold mb-4 block"
                style={{ color: '#64FFDA' }}
              >
                {a.number}
              </span>
              <h3
                className="font-body text-xl font-semibold mb-2"
                style={{ color: '#E6F1FF' }}
              >
                {a.title}
              </h3>
              <span
                className="font-body text-[13px] font-medium uppercase tracking-wider mb-3 block"
                style={{ color: '#F6A623' }}
              >
                {a.org}
              </span>
              <p
                className="font-body text-base leading-relaxed"
                style={{ color: '#8892B0' }}
              >
                {a.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Stats Bar */}
        <div
          ref={statsRef}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div
                className="font-display text-4xl lg:text-5xl font-bold mb-2"
                style={{ color: '#64FFDA' }}
              >
                <AnimatedCounter target={s.value} suffix={s.suffix} />
              </div>
              <span
                className="font-body text-[13px] font-medium uppercase tracking-wider"
                style={{ color: '#8892B0' }}
              >
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
