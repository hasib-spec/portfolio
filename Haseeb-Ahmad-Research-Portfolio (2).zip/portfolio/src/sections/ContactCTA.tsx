import { useEffect, useRef } from 'react';
import { Mail, Github, FileText, ArrowUpRight } from 'lucide-react';

const LINKS = [
  {
    icon: FileText,
    label: 'CV (PDF)',
    href: '/Haseeb_Ahmad_CV.pdf',
    desc: 'Full academic CV — education, research, and selected recognition.',
  },
  {
    icon: Github,
    label: 'GitHub',
    href: 'https://github.com/hasib-spec/',
    desc: 'Source code for Ichthyon and other computational projects.',
  },
  {
    icon: Mail,
    label: 'Email',
    href: 'mailto:haedu59@gmail.com',
    desc: 'Reach me directly for research-related correspondence.',
  },
];

export default function ContactCTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    if (!section || !content) return;

    const children = content.querySelectorAll('.cta-animate');
    children.forEach((child) => {
      const el = child as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
    });

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          children.forEach((child, i) => {
            const el = child as HTMLElement;
            setTimeout(() => {
              el.style.transition = 'opacity 0.8s cubic-bezier(0.33, 1, 0.68, 1), transform 0.8s cubic-bezier(0.33, 1, 0.68, 1)';
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
            }, i * 200);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="contact"
      ref={sectionRef}
      style={{
        background: 'linear-gradient(180deg, #0A192F 0%, #0D1F35 100%)',
        padding: '120px 0',
      }}
    >
      <div ref={contentRef} className="max-w-[1000px] mx-auto px-6 text-center">
        <span
          className="cta-animate font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-6 block"
          style={{ color: '#64FFDA' }}
        >
          Research Collaboration
        </span>

        <h2
          className="cta-animate font-display font-bold mb-6"
          style={{
            color: '#E6F1FF',
            fontSize: 'clamp(34px, 4.5vw, 50px)',
            lineHeight: 1.15,
          }}
        >
          Seeking doctoral research opportunities.
        </h2>

        <p
          className="cta-animate font-body text-lg mx-auto mb-12"
          style={{
            color: '#8892B0',
            maxWidth: 680,
            lineHeight: 1.7,
          }}
        >
          I am interested in PhD research at the intersection of computational toxicology, mechanistic modelling, AI-assisted prediction, and alternative approaches to animal testing. If your lab works in any of these areas and you are open to a conversation with a prospective doctoral applicant, I would welcome the opportunity to talk.
        </p>

        {/* Link Grid */}
        <div className="cta-animate grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {LINKS.map((link) => {
            const Icon = link.icon;
            return (
              <a
                key={link.label}
                href={link.href}
                target={link.href.startsWith('http') || link.href.endsWith('.pdf') ? '_blank' : undefined}
                rel={link.href.startsWith('http') || link.href.endsWith('.pdf') ? 'noopener noreferrer' : undefined}
                className="group rounded-xl p-6 text-left transition-all duration-300"
                style={{
                  backgroundColor: '#112240',
                  border: '1px solid #233554',
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = 'rgba(100, 255, 218, 0.4)';
                  el.style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = '#233554';
                  el.style.transform = 'translateY(0)';
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <Icon size={22} style={{ color: '#64FFDA' }} />
                  <ArrowUpRight
                    size={16}
                    style={{ color: '#8892B0' }}
                    className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  />
                </div>
                <h3
                  className="font-body text-base font-semibold mb-1"
                  style={{ color: '#E6F1FF' }}
                >
                  {link.label}
                </h3>
                <p
                  className="font-body text-sm"
                  style={{ color: '#8892B0', lineHeight: 1.5 }}
                >
                  {link.desc}
                </p>
              </a>
            );
          })}
        </div>

        <p
          className="cta-animate font-body text-base"
          style={{ color: '#8892B0' }}
        >
          For cold-email outreach, please reply directly to the email you received — I am happy to share additional materials on request.
        </p>
      </div>
    </section>
  );
}
