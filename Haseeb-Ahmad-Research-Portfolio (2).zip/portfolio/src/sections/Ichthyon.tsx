import { useEffect, useRef } from 'react';
import { Check, AlertCircle, ArrowRight } from 'lucide-react';

const METHODS = [
  '12-compartment physiologically-based toxicokinetic (PBTK) model',
  'Quantitative Adverse Outcome Pathway (qAOP) cascade framework',
  'GUTS-SD Monte Carlo calibration for time-dependent hazard',
  'Biotic Ligand Model (BLM) for metal bioavailability',
  'Weibull F1 epigenetic hazard scoring',
];

const IMPLEMENTATION = [
  'Python scientific stack (NumPy, SciPy, pandas)',
  'FastAPI backend for reproducible model execution',
  'React frontend for parameter exploration and visualisation',
  'Version-controlled, documented, and unit-tested workflows',
];

const LIMITATIONS = [
  'Validation set is limited to 28 compounds; broader chemical space coverage is needed before regulatory applicability can be claimed.',
  'Parameterisation relies on published physicochemical properties where experimental data are unavailable, introducing propagated uncertainty.',
  'The current qAOP cascade assumes linear cascade amplification; non-linear and compensatory feedback mechanisms are not yet modelled.',
  'Metabolism and elimination are parameterised at the organism level; tissue-specific metabolic clearance requires experimental refinement.',
];

const FUTURE_WORK = [
  'Expand validation to a structurally diverse set of 80+ compounds spanning multiple MOA classes.',
  'Incorporate Bayesian uncertainty quantification for predicted LC50 confidence intervals.',
  'Integrate in vitro to in vivo extrapolation (IVIVE) using ToxCast high-throughput screening data.',
  'Develop sensitivity analysis framework to identify parameters driving model output variance.',
];

export default function Ichthyon() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const right = rightRef.current;
    if (!section || !left || !right) return;

    left.style.opacity = '0';
    left.style.transform = 'translateX(-40px)';
    right.style.opacity = '0';
    right.style.transform = 'translateX(40px)';

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          left.style.transition = 'opacity 0.9s cubic-bezier(0.33, 1, 0.68, 1), transform 0.9s cubic-bezier(0.33, 1, 0.68, 1)';
          left.style.opacity = '1';
          left.style.transform = 'translateX(0)';

          setTimeout(() => {
            right.style.transition = 'opacity 0.9s cubic-bezier(0.33, 1, 0.68, 1), transform 0.9s cubic-bezier(0.33, 1, 0.68, 1)';
            right.style.opacity = '1';
            right.style.transform = 'translateX(0)';
          }, 200);

          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="research"
      ref={sectionRef}
      style={{ backgroundColor: '#112240', padding: '120px 0' }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-4 block"
            style={{ color: '#64FFDA' }}
          >
            Primary Research Project
          </span>
          <h2
            className="font-display text-5xl lg:text-[48px] font-bold mb-3"
            style={{ color: '#E6F1FF' }}
          >
            ICHTHYON
          </h2>
          <h3
            className="font-body text-xl lg:text-2xl font-semibold"
            style={{ color: '#64FFDA' }}
          >
            Mechanistic Computational Toxicology Platform
          </h3>
        </div>

        {/* Two Column Layout — Overview + Visualisation */}
        <div className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-12 lg:gap-16 mb-20">
          {/* Left Column — Research Question */}
          <div ref={leftRef}>
            <span
              className="font-body text-[13px] font-medium uppercase tracking-wider mb-3 block"
              style={{ color: '#F6A623' }}
            >
              Research Question
            </span>
            <h4
              className="font-display text-2xl lg:text-[32px] font-bold mb-6"
              style={{ color: '#E6F1FF', lineHeight: 1.3 }}
            >
              Can mechanistic, physiologically-based modelling predict acute aquatic toxicity with sufficient accuracy to reduce reliance on animal testing for regulatory screening?
            </h4>

            <p
              className="font-body text-lg mb-6"
              style={{ color: '#8892B0', lineHeight: 1.7 }}
            >
              Regulatory toxicology still depends heavily on in vivo LC50 tests, which are slow, costly, and ethically contested. Computational alternatives exist but are often narrow in scope or treated as black boxes. This project investigates whether a combined PBTK + qAOP + Monte Carlo framework can produce transparent, mechanistically interpretable toxicity predictions across multiple modes of action.
            </p>
            <p
              className="font-body text-base"
              style={{ color: '#8892B0', lineHeight: 1.7 }}
            >
              The work is independent and self-directed, undertaken alongside my Zoology undergraduate studies. It is not a polished regulatory tool — it is a research artefact intended to demonstrate methodology, rigour, and the explicit boundaries of what the model can and cannot currently do.
            </p>
          </div>

          {/* Right Column — Visualisation + Validation */}
          <div ref={rightRef} className="flex flex-col items-center justify-center">
            {/* Abstract Visualisation */}
            <div
              className="w-full aspect-square rounded-xl mb-8 relative overflow-hidden"
              style={{
                background: 'linear-gradient(145deg, #0A192F 0%, #1a365d 50%, #0A192F 100%)',
                border: '1px solid #233554',
              }}
            >
              <svg
                viewBox="0 0 400 400"
                className="w-full h-full"
                style={{ opacity: 0.8 }}
              >
                {/* Central node */}
                <circle cx="200" cy="200" r="16" fill="#64FFDA" opacity="0.9" />
                {/* Surrounding nodes — 12 compartments */}
                {[...Array(12)].map((_, i) => {
                  const angle = (i * 30 * Math.PI) / 180;
                  const r = 120;
                  const x = 200 + r * Math.cos(angle);
                  const y = 200 + r * Math.sin(angle);
                  const innerR = 60;
                  const ix = 200 + innerR * Math.cos(angle);
                  const iy = 200 + innerR * Math.sin(angle);
                  return (
                    <g key={i}>
                      <line x1="200" y1="200" x2={x} y2={y} stroke="#64FFDA" strokeWidth="1" opacity="0.3" />
                      <line x1="200" y1="200" x2={ix} y2={iy} stroke="#F6A623" strokeWidth="1" opacity="0.25" />
                      <circle cx={x} cy={y} r="8" fill="#64FFDA" opacity="0.7">
                        <animate attributeName="opacity" values="0.7;0.3;0.7" dur={`${2 + i * 0.3}s`} repeatCount="indefinite" />
                      </circle>
                      <circle cx={ix} cy={iy} r="4" fill="#F6A623" opacity="0.5">
                        <animate attributeName="r" values="4;6;4" dur={`${3 + i * 0.2}s`} repeatCount="indefinite" />
                      </circle>
                    </g>
                  );
                })}
                {/* Second ring */}
                {[...Array(8)].map((_, i) => {
                  const angle = (i * 45 * Math.PI) / 180;
                  const r = 80;
                  const x = 200 + r * Math.cos(angle);
                  const y = 200 + r * Math.sin(angle);
                  return (
                    <circle key={`inner-${i}`} cx={x} cy={y} r="5" fill="#E6F1FF" opacity="0.3">
                      <animate attributeName="opacity" values="0.3;0.6;0.3" dur={`${2.5 + i * 0.4}s`} repeatCount="indefinite" />
                    </circle>
                  );
                })}
                {/* Label */}
                <text
                  x="200"
                  y="340"
                  textAnchor="middle"
                  fill="#E6F1FF"
                  fontSize="14"
                  fontFamily="'JetBrains Mono', monospace"
                  opacity="0.6"
                >
                  12-Compartment PBTK Model
                </text>
              </svg>
            </div>

            {/* Validation Badge — precise definition */}
            <div className="text-center">
              <div
                className="font-display text-6xl lg:text-7xl font-bold mb-2"
                style={{ color: '#64FFDA' }}
              >
                23 / 28
              </div>
              <span
                className="font-body text-[13px] font-medium uppercase tracking-wider block mb-2"
                style={{ color: '#8892B0' }}
              >
                Compounds Within ±2× LC50 Acceptance Window
              </span>
              <span
                className="font-body text-sm italic"
                style={{ color: '#A8B2D1' }}
              >
                (82.1% pass rate) · 93 ECOTOX reference data points used for calibration
              </span>
            </div>
          </div>
        </div>

        {/* Methods */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-wider mb-4 block"
            style={{ color: '#F6A623' }}
          >
            Methods
          </span>
          <h4
            className="font-display text-2xl lg:text-3xl font-bold mb-6"
            style={{ color: '#E6F1FF' }}
          >
            Mechanistic framework
          </h4>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {METHODS.map((m) => (
              <li key={m} className="flex items-start gap-3">
                <Check size={18} style={{ color: '#64FFDA', flexShrink: 0, marginTop: 4 }} />
                <span className="font-body text-base" style={{ color: '#A8B2D1' }}>
                  {m}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Implementation */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-wider mb-4 block"
            style={{ color: '#F6A623' }}
          >
            Implementation
          </span>
          <h4
            className="font-display text-2xl lg:text-3xl font-bold mb-6"
            style={{ color: '#E6F1FF' }}
          >
            Reproducible scientific software
          </h4>
          <p
            className="font-body text-base mb-6"
            style={{ color: '#8892B0', lineHeight: 1.7, maxWidth: 800 }}
          >
            The platform is implemented as ~9,830 lines of Python with a FastAPI backend and a React frontend for interactive parameter exploration. The emphasis is on reproducible computational workflows: version-controlled source, documented model assumptions, and unit tests for numerical components.
          </p>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {IMPLEMENTATION.map((m) => (
              <li key={m} className="flex items-start gap-3">
                <Check size={18} style={{ color: '#64FFDA', flexShrink: 0, marginTop: 4 }} />
                <span className="font-body text-base" style={{ color: '#A8B2D1' }}>
                  {m}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Validation & Results */}
        <div className="mb-16 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div
            className="rounded-xl p-8"
            style={{ backgroundColor: '#0A192F', border: '1px solid #233554' }}
          >
            <span
              className="font-body text-[13px] font-medium uppercase tracking-wider mb-3 block"
              style={{ color: '#F6A623' }}
            >
              Validation
            </span>
            <p
              className="font-body text-base mb-4"
              style={{ color: '#A8B2D1', lineHeight: 1.7 }}
            >
              Predicted LC50 values were compared against gold-standard ECOTOX reference data. A prediction was considered acceptable when it fell within a ±2× window of the experimentally observed LC50 — a standard regulatory tolerance for acute toxicity models.
            </p>
            <p
              className="font-body text-base"
              style={{ color: '#A8B2D1', lineHeight: 1.7 }}
            >
              Of 28 validated compounds, 23 fell within this acceptance window (82.1%). The 93 ECOTOX data points served as the calibration reference set across multiple species and modes of action.
            </p>
          </div>
          <div
            className="rounded-xl p-8"
            style={{ backgroundColor: '#0A192F', border: '1px solid #233554' }}
          >
            <span
              className="font-body text-[13px] font-medium uppercase tracking-wider mb-3 block"
              style={{ color: '#F6A623' }}
            >
              Results
            </span>
            <p
              className="font-body text-base mb-4"
              style={{ color: '#A8B2D1', lineHeight: 1.7 }}
            >
              The framework demonstrates that a combined PBTK + qAOP + Monte Carlo approach can predict acute aquatic toxicity within regulatory tolerance for the majority of tested compounds, including representatives of narcotic, reactive, and specifically-acting modes of action.
            </p>
            <p
              className="font-body text-base"
              style={{ color: '#A8B2D1', lineHeight: 1.7 }}
            >
              The 5 compounds falling outside the acceptance window share structural features that suggest specific metabolic pathways not yet captured by the model — a concrete direction for refinement.
            </p>
          </div>
        </div>

        {/* Limitations */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <AlertCircle size={22} style={{ color: '#F6A623' }} />
            <h4
              className="font-display text-2xl lg:text-3xl font-bold"
              style={{ color: '#E6F1FF' }}
            >
              Limitations
            </h4>
          </div>
          <p
            className="font-body text-base mb-6"
            style={{ color: '#8892B0', lineHeight: 1.7, maxWidth: 800 }}
          >
            Stating the boundaries of what this model can and cannot currently do is part of the work, not an afterthought. The following limitations are explicit and would guide future experimental validation:
          </p>
          <ul className="space-y-3">
            {LIMITATIONS.map((l) => (
              <li key={l} className="flex items-start gap-3">
                <span
                  className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                  style={{ backgroundColor: '#F6A623' }}
                />
                <span className="font-body text-base" style={{ color: '#A8B2D1', lineHeight: 1.6 }}>
                  {l}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Future Work */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <ArrowRight size={22} style={{ color: '#64FFDA' }} />
            <h4
              className="font-display text-2xl lg:text-3xl font-bold"
              style={{ color: '#E6F1FF' }}
            >
              Future Work
            </h4>
          </div>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {FUTURE_WORK.map((f) => (
              <li key={f} className="flex items-start gap-3">
                <Check size={18} style={{ color: '#64FFDA', flexShrink: 0, marginTop: 4 }} />
                <span className="font-body text-base" style={{ color: '#A8B2D1' }}>
                  {f}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Manuscript & Repository Note */}
        <div
          className="text-center pt-8"
          style={{ borderTop: '1px solid #233554' }}
        >
          <p
            className="font-body text-base italic"
            style={{ color: '#8892B0' }}
          >
            Manuscript in preparation. Source code available on request.
          </p>
        </div>
      </div>
    </section>
  );
}
