import { useEffect, useRef } from 'react';
import { Atom, ShieldCheck, GitBranch } from 'lucide-react';

const PRINCIPLES = [
  {
    icon: Atom,
    title: 'First Principles over Black Boxes',
    desc: 'I try to understand the mechanistic assumptions underlying a model rather than treating established software as an opaque tool. When I use a published approach, I want to know which biological assumptions it encodes, where those assumptions break down, and what the model cannot tell me — not just what output it produces.',
  },
  {
    icon: ShieldCheck,
    title: 'Validation before Confidence',
    desc: 'I treat quantitative validation and uncertainty analysis as necessary components of computational modelling, not as post-hoc demonstrations added once the work is done. A model that has not been tested against independent data is a hypothesis, not a result. Stating the limits of what a model can predict is part of the work itself.',
  },
  {
    icon: GitBranch,
    title: 'Interdisciplinary Learning',
    desc: 'My background in zoology led me toward computational toxicology, which required independent study across mathematical modelling, programming, statistics, and regulatory science. I do not see these as separate domains but as overlapping layers of the same problem — predicting chemical hazard mechanistically rather than empirically.',
  },
];

export default function Philosophy() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current;
    if (!section || !cards) return;

    const cardEls = cards.querySelectorAll('.philosophy-card');
    cardEls.forEach((card) => {
      const el = card as HTMLElement;
      el.style.opacity = '0';
      el.style.transform = 'translateY(40px)';
    });

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          cardEls.forEach((card, i) => {
            const el = card as HTMLElement;
            setTimeout(() => {
              el.style.transition = 'opacity 0.8s cubic-bezier(0.33, 1, 0.68, 1), transform 0.8s cubic-bezier(0.33, 1, 0.68, 1)';
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
            }, i * 150);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="philosophy"
      ref={sectionRef}
      style={{ backgroundColor: '#112240', padding: '120px 0' }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <span
            className="font-body text-[13px] font-medium uppercase tracking-[0.1em] mb-4 block"
            style={{ color: '#64FFDA' }}
          >
            Research Philosophy
          </span>
          <h2
            className="font-display text-4xl lg:text-[40px] font-bold mb-4"
            style={{ color: '#E6F1FF' }}
          >
            How I Approach Research
          </h2>
          <p
            className="font-body text-lg"
            style={{ color: '#8892B0', maxWidth: 640, lineHeight: 1.7 }}
          >
            I have been able to build difficult things independently. The reason I am seeking doctoral research is to learn how to do rigorous science at a higher level — with expert supervision, access to experimental data, and the discipline of a research group.
          </p>
        </div>

        {/* Philosophy Cards */}
        <div ref={cardsRef} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {PRINCIPLES.map((p) => {
            const Icon = p.icon;
            return (
              <div
                key={p.title}
                className="philosophy-card rounded-xl p-10"
                style={{
                  backgroundColor: '#0A192F',
                  border: '1px solid #233554',
                }}
              >
                <div
                  className="w-12 h-12 rounded-lg flex items-center justify-center mb-6"
                  style={{
                    backgroundColor: 'rgba(100, 255, 218, 0.1)',
                    border: '1px solid rgba(100, 255, 218, 0.3)',
                  }}
                >
                  <Icon size={24} style={{ color: '#64FFDA' }} />
                </div>
                <h3
                  className="font-body text-xl font-semibold mb-4"
                  style={{ color: '#E6F1FF' }}
                >
                  {p.title}
                </h3>
                <p
                  className="font-body text-base"
                  style={{ color: '#8892B0', lineHeight: 1.7 }}
                >
                  {p.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
