import { useEffect, useRef, useState } from 'react';
import { Menu, X } from 'lucide-react';

const NAV_LINKS = [
  { label: 'About', href: '#hero' },
  { label: 'Recognition', href: '#achievements' },
  { label: 'Research', href: '#research' },
  { label: 'Skills', href: '#skills' },
  { label: 'Philosophy', href: '#philosophy' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');
  const [menuOpen, setMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 100);

      const sections = NAV_LINKS.map((l) => l.href.slice(1));
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 200) {
            setActiveSection(sections[i]);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setMenuOpen(false);
  };

  return (
    <>
      <nav
        ref={navRef}
        className="fixed top-0 left-0 right-0 z-[1000] transition-all duration-300"
        style={{
          height: 80,
          backgroundColor: scrolled ? 'rgba(10, 25, 47, 0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(12px)' : 'none',
          borderBottom: scrolled ? '1px solid #233554' : '1px solid transparent',
        }}
      >
        <div className="max-w-[1200px] mx-auto h-full flex items-center justify-between px-6">
          {/* Logo */}
          <a
            href="#hero"
            onClick={(e) => handleNavClick(e, '#hero')}
            className="font-display text-2xl font-bold"
            style={{ color: '#64FFDA' }}
          >
            HA.
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-7">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-body text-[13px] font-medium uppercase tracking-wider transition-colors duration-200 relative"
                style={{
                  color: activeSection === link.href.slice(1) ? '#64FFDA' : '#E6F1FF',
                }}
              >
                {link.label}
                {activeSection === link.href.slice(1) && (
                  <span
                    className="absolute -bottom-1 left-0 right-0 h-[2px]"
                    style={{ backgroundColor: '#64FFDA' }}
                  />
                )}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="hidden md:inline-flex items-center font-body text-sm font-medium px-5 py-2.5 rounded-full transition-all duration-200 hover:scale-105"
            style={{
              backgroundColor: '#F6A623',
              color: '#0A192F',
            }}
          >
            Contact
          </a>

          {/* Mobile Hamburger */}
          <button
            className="lg:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ color: '#E6F1FF' }}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-[999] flex flex-col items-center justify-center gap-8 lg:hidden"
          style={{ backgroundColor: '#0A192F' }}
        >
          {NAV_LINKS.map((link, i) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="font-display text-3xl font-bold transition-all duration-300"
              style={{
                color: activeSection === link.href.slice(1) ? '#64FFDA' : '#E6F1FF',
                animationDelay: `${i * 0.08}s`,
                animation: 'fadeInUp 0.4s ease forwards',
                opacity: 0,
              }}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="font-body text-base font-medium px-8 py-3 rounded-full mt-4"
            style={{
              backgroundColor: '#F6A623',
              color: '#0A192F',
              animationDelay: `${NAV_LINKS.length * 0.08}s`,
              animation: 'fadeInUp 0.4s ease forwards',
              opacity: 0,
            }}
          >
            Contact
          </a>
        </div>
      )}

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </>
  );
}
