import { useEffect, useRef } from 'react';

interface Cell {
  homeX: number;
  homeY: number;
  currentX: number;
  currentY: number;
  char: string;
  isLetter: boolean;
}

export default function AsciiCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<Cell[][]>([]);
  const mouseRef = useRef({ x: 0, y: 0, inside: false });
  const rafRef = useRef<number>(0);
  const orbitAngleRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const fontSize = 12;
    const disruptionRadius = 120;
    const repelStrength = 30;
    const orbitStrength = 15;
    const lerpSpeedIn = 0.12;
    const lerpSpeedOut = 0.08;
    const orbitSpeed = 0.02;
    const letterColor = '#64FFDA';
    const bgColor = '#8892B0';

    const letterChars = ['@', '#', '$', '%', '&', '*', 'H', 'A'];
    const backgroundChars = ['.', ':', '-', ' ', '+', '~'];

    function buildGrid() {
      const w = container!.clientWidth;
      const h = container!.clientHeight;
      canvas!.width = w;
      canvas!.height = h;

      const columns = Math.floor(w / fontSize);
      const rows = Math.floor(h / fontSize);

      // Offscreen canvas to detect letter shapes
      const offscreen = document.createElement('canvas');
      offscreen.width = w;
      offscreen.height = h;
      const offCtx = offscreen.getContext('2d');
      if (!offCtx) return;

      offCtx.fillStyle = '#000000';
      offCtx.fillRect(0, 0, w, h);
      offCtx.fillStyle = '#ffffff';
      offCtx.font = `700 ${Math.floor(h * 0.65)}px "Libre Baskerville", serif`;
      offCtx.textAlign = 'center';
      offCtx.textBaseline = 'middle';
      offCtx.fillText('HA', w / 2, h / 2);

      const imageData = offCtx.getImageData(0, 0, w, h).data;

      const grid: Cell[][] = [];
      for (let row = 0; row < rows; row++) {
        grid[row] = [];
        for (let col = 0; col < columns; col++) {
          const x = col * fontSize + fontSize / 2;
          const y = row * fontSize + fontSize / 2;
          const pixelIndex = (Math.floor(y) * w + Math.floor(x)) * 4;
          const isLetter = imageData[pixelIndex] > 128;

          const charPool = isLetter ? letterChars : backgroundChars;
          const char = charPool[Math.floor(Math.random() * charPool.length)];

          grid[row][col] = {
            homeX: col * fontSize,
            homeY: row * fontSize,
            currentX: col * fontSize,
            currentY: row * fontSize,
            char,
            isLetter,
          };
        }
      }
      gridRef.current = grid;
    }

    function render() {
      if (!ctx || !canvas) return;
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);
      ctx.font = `${fontSize}px "JetBrains Mono", monospace`;

      const grid = gridRef.current;
      const mouse = mouseRef.current;
      orbitAngleRef.current += orbitSpeed;

      for (let row = 0; row < grid.length; row++) {
        for (let col = 0; col < grid[row].length; col++) {
          const cell = grid[row][col];
          const dx = cell.currentX - mouse.x;
          const dy = cell.currentY - mouse.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < disruptionRadius && mouse.inside) {
            const force = (disruptionRadius - dist) / disruptionRadius;
            const repelX = (dx / (dist || 1)) * force * repelStrength;
            const repelY = (dy / (dist || 1)) * force * repelStrength;
            const angle = Math.atan2(dy, dx) + orbitAngleRef.current;
            const orbitX = Math.cos(angle) * force * orbitStrength;
            const orbitY = Math.sin(angle) * force * orbitStrength;
            const targetX = cell.homeX + repelX + orbitX;
            const targetY = cell.homeY + repelY + orbitY;
            cell.currentX += (targetX - cell.currentX) * lerpSpeedIn;
            cell.currentY += (targetY - cell.currentY) * lerpSpeedIn;
          } else {
            cell.currentX += (cell.homeX - cell.currentX) * lerpSpeedOut;
            cell.currentY += (cell.homeY - cell.currentY) * lerpSpeedOut;
          }

          ctx.fillStyle = cell.isLetter ? letterColor : bgColor;
          ctx.fillText(cell.char, cell.currentX, cell.currentY);
        }
      }

      rafRef.current = requestAnimationFrame(render);
    }

    function handleMouseMove(e: MouseEvent) {
      const rect = canvas!.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
    }

    function handleMouseLeave() {
      mouseRef.current.inside = false;
    }

    function handleMouseEnter() {
      mouseRef.current.inside = true;
    }

    let resizeTimeout: ReturnType<typeof setTimeout>;
    function handleResize() {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        buildGrid();
      }, 150);
    }

    buildGrid();
    rafRef.current = requestAnimationFrame(render);

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);
    canvas.addEventListener('mouseenter', handleMouseEnter);
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafRef.current);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
      canvas.removeEventListener('mouseenter', handleMouseEnter);
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeout);
    };
  }, []);

  return (
    <div ref={containerRef} style={{ width: '100%', height: '100%', position: 'relative' }}>
      <canvas
        ref={canvasRef}
        role="img"
        aria-label="Interactive ASCII art displaying HA initials"
        style={{ display: 'block', width: '100%', height: '100%' }}
      />
    </div>
  );
}
